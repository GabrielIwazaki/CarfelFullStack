using System;
using System.Collections.Generic;
using System.IO;
using Senai.Projeto.Carfel.Models;

namespace Senai.Projeto.Carfel.Repositorios {
    public class ComentarioRepositorio {
        private List<ComentarioModel> CarregarCSVComentario () {
            List<ComentarioModel> lsComentario = new List<ComentarioModel> ();
            string[] linhas = File.ReadAllLines ("comentarios.csv");

            foreach (string linha in linhas) {
                string[] dadosDaLinha = linha.Split (';');
                if (string.IsNullOrEmpty (linha)) {
                    continue;
                }

                ComentarioModel comentario = new ComentarioModel (

                    nome : dadosDaLinha[1],
                    id: int.Parse (dadosDaLinha[0]),
                    texto: dadosDaLinha[2],
                    data: DateTime.Parse (dadosDaLinha[3]),
                    stats: bool.Parse (dadosDaLinha[4])
                );
                

                lsComentario.Add (comentario);
            }
            return lsComentario;
        }

        public List<ComentarioModel> Listar () => CarregarCSVComentario ();

        // public ComentarioModel Editar (ComentarioModel comentario) {
        //     string[] linhas = System.IO.File.ReadAllLines ("comentarios.csv");
        //     for (int i = 0; i < linhas.Length; i++) {
        //         if (string.IsNullOrEmpty ((linhas[i]))) {
        //             continue;
        //         }
        //         string[] dadosDaLinha = linhas[i].Split (",");
        //         if (dadosDaLinha[0] == comentario.Id.ToString ()) {
        //             linhas[i] = $"{comentario.Id};{comentario.Nome};{comentario.Texto};{comentario.DataCriacao};{comentario.Status}";
        //             break;

        //         }
        //     }
        //     System.IO.File.WriteAllLines ("comentarios.csv", linhas);

        //     return comentario;
        // }
            public void Editar (int id) {
            string[] linhas = System.IO.File.ReadAllLines ("comentarios.csv");
            for (int i = 0; i < linhas.Length; i++) {
                if (string.IsNullOrEmpty ((linhas[i]))) {
                    continue;
                }
                string[] dadosDaLinha = linhas[i].Split (",");
                if (id.ToString () == dadosDaLinha[0]) {
                    linhas[i] = ($"{dadosDaLinha[0]};{dadosDaLinha[1]};{dadosDaLinha[2]};{dadosDaLinha[3]};{true}");
                    break;

                }
            }
            System.IO.File.WriteAllLines ("comentarios.csv", linhas);

        
        }
        public ComentarioModel BuscarPorId (int id) {
            string[] linhas = System.IO.File.ReadAllLines ("Comentarios.csv");
            for (int i = 0; i < linhas.Length; i++) {
                if (string.IsNullOrEmpty ((linhas[i]))) {
                    continue;
                }
                string[] dadosDaLinha = linhas[i].Split (";");
                if (dadosDaLinha[0] == id.ToString ()) {
                    ComentarioModel comentario = new ComentarioModel (
                        nome:  dadosDaLinha[1],
                        id:  int.Parse (dadosDaLinha[0]),
                        texto:  dadosDaLinha[2],
                        data:  DateTime.Parse (dadosDaLinha[3]),
                         stats: bool.Parse (dadosDaLinha[4])
                    );
                    return comentario;
                }
            }
                return null;
        }
    }
}
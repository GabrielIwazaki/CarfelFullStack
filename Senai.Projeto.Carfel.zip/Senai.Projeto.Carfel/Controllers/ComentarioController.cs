using System;
using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Senai.Projeto.Carfel.Models;
using Senai.Projeto.Carfel.Repositorios;

namespace Senai.Projeto.Carfel.Controllers {
    public class ComentarioController : Controller {
        [HttpGet]
        public IActionResult Cadastrar () {
            if (string.IsNullOrEmpty (HttpContext.Session.GetString ("idUsuario"))) {
                return RedirectToAction ("Login", "Usuario");
            }
            return View ();
        }

        [HttpPost]
        public IActionResult Cadastrar (IFormCollection form) {
            ComentarioModel comentario = new ComentarioModel ();

            int id = 0;
            bool status = false;

            if (System.IO.File.Exists ("comentarios.csv")) {
                string[] linhas = System.IO.File.ReadAllLines ("comentarios.csv");
                comentario.Id = linhas.Length + 1;
            } else {
                comentario.Id = 1;
            }

            String Nome = HttpContext.Session.GetString ("nomeUsuario");

          
            comentario.Nome = Nome;
            comentario.Texto = form["texto"];
            comentario.DataCriacao = DateTime.Now;
            comentario.Status = status;

            using (StreamWriter sw = new StreamWriter ("comentarios.csv", true)) {
                sw.WriteLine ($"{comentario.Id};{comentario.Nome};{comentario.Texto};{comentario.DataCriacao};{comentario.Status}");
            }

            ViewBag.Mensagem = "Comentário aguardando por verificação";

            return View ();

        }

        [HttpGet]
        public ActionResult Editar (int id) {
            if (id == 0) {
                return RedirectToAction ("Listar");
            }
            ComentarioRepositorio comentariorep = new ComentarioRepositorio ();
            ComentarioModel comentario = comentariorep.BuscarPorId (id);
            if (comentario != null) {
                ViewBag.comentario = comentario;
            } else {
                TempData["Mensagem"] = "Comentario nao encontrado";
                return RedirectToAction ("Listar");
            }
            return View ();
        }
        [HttpPost]
        public IActionResult Editar (IFormCollection formulario) {
            ComentarioModel comentario = new ComentarioModel (
                nome: formulario["nome"],
                id: int.Parse (formulario["id"]),
                texto: formulario["texto"],
                data: DateTime.Parse (formulario["data"]),
                stats: bool.Parse (formulario["status"])
            );
            ComentarioRepositorio comentarioRep = new ComentarioRepositorio ();
            comentarioRep.Editar(comentario.Id);
            TempData["Mensagem"] = "Nois que voa bruxão";
            return  RedirectToAction("Listar");
        }
        [HttpGet]
        public IActionResult Listar(){
            ComentarioRepositorio comentarioRep =  new ComentarioRepositorio();
            ViewData["Comentarios"]= comentarioRep.Listar();
            return View();
        }
    }
}
using Microsoft.AspNetCore.Mvc;

namespace Senai.Projeto.Carfel.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index(){
            return View();
        }
    }
}
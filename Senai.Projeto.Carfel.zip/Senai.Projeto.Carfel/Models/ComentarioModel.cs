using System;

namespace Senai.Projeto.Carfel.Models
{
    public class ComentarioModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Texto { get; set; }
        public DateTime DataCriacao { get; set; }
        public bool Status { get; set; }

        // Criar metodo construtor
       public ComentarioModel (string nome, int id, string texto, DateTime data, bool stats){
           this.Nome = nome;
           this.Id =  id;
           this.Texto = texto;
           this.DataCriacao = data;
           this.Status = stats;
        }

        public ComentarioModel()
        {
        }
    }
}